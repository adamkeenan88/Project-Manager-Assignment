const ProductController = require("../controllers/product.controller");

module.exports = (app) => {
  app.get("/healthcheck", (req, res) => {
    res.send("Everything ok");
  });
  app.post("/api/product", ProductController.createProduct);
  app.get("/api", ProductController.findProduct);
  app.get("/api/product/:productId", ProductController.findOneProduct);
  app.put("/api/product/:productId", ProductController.updateProduct);
  app.delete("/api/product/:productId", ProductController.deleteProduct);
};
