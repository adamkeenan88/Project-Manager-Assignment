import { navigate } from "@reach/router";
import axios from "axios";
import React, { useState, useEffect } from "react";

const EditProduct = (props) => {
  const { productId } = props;
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");

  useEffect(() => {
    axios
      .get(`http://localhost:8000/api/product/${productId}`)
      .then((queriedProduct) => {
        console.log(queriedProduct.data);

        setTitle(queriedProduct.data.product.title);
        setPrice(queriedProduct.data.product.price);
        setDescription(queriedProduct.data.product.description);
      })
      .catch((err) => console.log(err));
  }, []);

  const handleSubmitUpdate = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:8000/api/product/${productId}`, {
        title,
        price,
        description,
      })
      .then((updatedDoc) => navigate("/"))
      .catch((err) => console.log(err));
  };
  return (
    <div>
      <form onSubmit={handleSubmitUpdate}>
        <div>
          Title:{" "}
          <input
            type="text"
            name="title"
            onChange={(e) => setTitle(e.target.value)}
            value={title}
          />
        </div>
        <div>
          Price:{" "}
          <input
            type="text"
            name="price"
            onChange={(e) => setPrice(e.target.value)}
            value={price}
          />
        </div>
        <div>
          Description:{" "}
          <input
            type="text"
            name="description"
            onChange={(e) => setDescription(e.target.value)}
            value={description}
          />
        </div>
        <button>SUBMIT EDIT</button>
      </form>
    </div>
  );
};

export default EditProduct;
