import React, { useState } from "react";
import axios from "axios";
const ProductForm = (props) => {
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const { formSubmittedBoolen, setFormSubmittedBoolean } = props;

  const onSubmitHandler = (e) => {
    e.preventDefault();
    console.log("success");
    const newProductData = { title, price, description };
    console.log(newProductData);
    axios
      .post("http://localhost:8000/api/product", newProductData)
      .then((newProduct) => {
        setTitle("");
        setPrice("");
        setDescription("");
        setFormSubmittedBoolean(!formSubmittedBoolen);
      })
      .catch((err) => console.log(err));
  };

  return (
    <form onSubmit={onSubmitHandler}>
      <p>
        <label>Title</label>
        <input type="text" onChange={(e) => setTitle(e.target.value)} />
      </p>
      <p>
        <label>Price</label>
        <input type="text" onChange={(e) => setPrice(e.target.value)} />
      </p>
      <p>
        <label>Description</label>
        <input type="text" onChange={(e) => setDescription(e.target.value)} />
      </p>
      <input type="submit" />
    </form>
  );
};
export default ProductForm;
