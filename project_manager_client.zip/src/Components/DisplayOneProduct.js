import { navigate } from "@reach/router";
import axios from "axios";
import { useEffect, useState } from "react";

const DisplayOneProduct = (props) => {
  const { productId } = props;
  const [productInfo, setProductInfo] = useState();
  useEffect(() => {
    axios
      .get(`http://localhost:8000/api/product/${productId}`)
      .then((queriedProduct) => {
        console.log(queriedProduct.data.product);
        setProductInfo(queriedProduct.data.product);
      })
      .catch((err) => console.log(err.response));
  }, []);

  const deleteProduct = (id) => {
    axios
      .delete(`http://localhost:8000/api/product/${id}`)
      .then((response) => {
        console.log("deletion successful");
        navigate("/");
      })
      .catch((err) => console.log("error deleting product", err));
  };

  return (
    <>
      {productInfo ? (
        <div>
          <h1>Display Product</h1>
          <p>{productInfo.title}</p>
          <p>{productInfo.price}</p>
          <p>{productInfo.description}</p>
          <button onClick={() => deleteProduct(productInfo._id)}>DELETE</button>
        </div>
      ) : (
        <h1>DTA IS LOADING</h1>
      )}
    </>
  );
};

export default DisplayOneProduct;
