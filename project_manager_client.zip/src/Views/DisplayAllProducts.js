import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "@reach/router";

const DisplayAllProducts = (props) => {
  const { formSubmittedBoolean, setFormSubmittedBoolean } = props;
  const [products, setProducts] = useState([]);

  useEffect(() => {
    console.log("useeffect triggered");
    axios
      .get("http://localhost:8000/api")
      .then((allProducts) => {
        console.log(allProducts.data.product);
        setProducts(allProducts.data.product);
      })
      .catch((err) => console.log(err));
  }, [formSubmittedBoolean]);

  const deleteProduct = (id) => {
    axios
      .delete(`http://localhost:8000/api/product/${id}`)
      .then((response) => {
        console.log("deletion successful");
        setFormSubmittedBoolean(!formSubmittedBoolean);
      })
      .catch((err) => console.log("error deleting product", err));
  };
  return (
    <div>
      <h1>Display All Products</h1>
      {products
        ? products.length > 0 &&
          products.map((product, index) => (
            <div key={index}>
              <h2>
                <Link to={`/product/${product._id}/edit`}>EDIT</Link>
              </h2>
              <Link to={`/product/${product._id}`}>Display Product Info</Link>
              <p>{product.title}</p>
              <p>{product.price}</p>
              <p>{product.description}</p>
              <button onClick={() => deleteProduct(product._id)}>
                Delete Product
              </button>
              <hr />
            </div>
          ))
        : "Product Loading"}
      ;
    </div>
  );
};

export default DisplayAllProducts;
