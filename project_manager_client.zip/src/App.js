import React from "react";
import { Router } from "@reach/router";
import Main from "./Views/Main";
import DisplayOneProduct from "./Components/DisplayOneProduct";
import EditProduct from "./Components/EditProduct";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Router>
        <Main path="/" />
        <EditProduct path="/product/:productId/edit" />
        <DisplayOneProduct path="/product/:productId" />
      </Router>
    </div>
  );
}
export default App;
